module Foreman

  VERSION = "0.60.0"

end
